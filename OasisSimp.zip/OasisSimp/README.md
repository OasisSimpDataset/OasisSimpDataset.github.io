# OasisSimp Dataset

Each language has its own folder containing two JSONL files corresponding to `valid` and `test` set. 

## Directory Structure

Folder contains:

OasisSimp-EN/
├── OasisSimp-EN_valid.jsonl
├── OasisSimp-EN_test.jsonl
OasisSimp-PS/
├── OasisSimp-PS_valid.jsonl
├── OasisSimp-PS_test.jsonl
OasisSimp-SI/
├── OasisSimp-SI_valid.jsonl
├── OasisSimp-SI_test.jsonl
OasisSimp-TA/
├── OasisSimp-TA_valid.jsonl
├── OasisSimp-TA_test.jsonl
OasisSimp-TH/
├── OasisSimp-TH_valid.jsonl
├── OasisSimp-TH_test.jsonl



## JSONL File Structure

Each line in a JSONL file is a JSON object with the following fields:

| Field      | Type   | Description |
|------------|--------|-------------|
| `id`       | string | Unique identifier|
| `complex`  | string | Complex sentence|
| `simple`   | list   | List of simplified versions of the complex sentence |

### Example

```json
{
  "id": "OasisSimp-EN_valid_0",
  "complex": "And it set a July 2017 deadline for determining whether transgender people could be allowed to enter the military.",
  "simple": [
    "A July 2017 deadline was set to decide on transgender military enlistment.",
    "It set a deadline in July 2017 to decide if transgender people can join the military.",
    "It gave a deadline of July 2017 to decide if transgender people can join the military."
  ]
}